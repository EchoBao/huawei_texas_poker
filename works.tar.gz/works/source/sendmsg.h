//sendmsg.c的头文件

int SendMsg(int type);
