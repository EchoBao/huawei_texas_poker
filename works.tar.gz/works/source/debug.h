//debug.c头文件，声明相关函数

void PrintGameInfo(void);//打印GameInfo结构体信息函数，用于调试
int PrintIDInfo(void);//打印IDInfo结构体信息，用于调试
int PrintBlindInfo(void);//打印盲注信息
int PrintCardInfo(void);//打印牌型信息
int PrintMyUpper(void);//打印我的上家信息
void PrintAnaly(void);
